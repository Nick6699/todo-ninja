import Vue from 'vue';
import Vcharts from 'v-charts'
Vue.use(Vcharts);

export default new Vcharts({
  
});
